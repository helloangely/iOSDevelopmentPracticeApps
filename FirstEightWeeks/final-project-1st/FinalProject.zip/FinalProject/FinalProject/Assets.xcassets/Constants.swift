//
//  Constants.swift
//  FinalProject
//
//  Created by Eleftheri, Samuel Evangelos on 10/10/16.
//  Copyright © 2016 Philip, Angely. All rights reserved.
//

import Foundation

let userKey = "user"
var tableViewArray = ["hw", "wash dishes", "feed dog"]
