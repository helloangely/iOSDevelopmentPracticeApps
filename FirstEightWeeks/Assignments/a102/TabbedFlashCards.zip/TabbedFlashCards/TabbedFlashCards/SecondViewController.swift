//
//  SecondViewController.swift
//  TabbedFlashCards
//
//  Created by Philip, Angely on 9/16/16.
//  Copyright © 2016 A290 Spring 2016 - anphilip selefthe. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
    
    // the reference to our AppDelegate:
    var appDelegate: AppDelegate?
    // the reference to our data model:
    var myFlashCardModel: FlashCardModel?
    
    @IBOutlet var questionTextField: UITextField!
    
    @IBOutlet var answerTextField: UITextField!
    
    @IBAction func buttonOKAction(sender: AnyObject) {
        
        // obtain a reference to the AppDelegate:
        self.appDelegate = UIApplication.sharedApplication().delegate as? AppDelegate
        // from the AppDelegate, obtain a reference to the Model data:
        self.myFlashCardModel = self.appDelegate?.myFlashCardModel
        
        print ("self.questionTextField.text = \(self.questionTextField.text)")
        print ("self.answerTextField.text = \(self.answerTextField.text)")
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        // obtain a reference to the AppDelegate:
        //self.appDelegate = UIApplication.sharedApplication().delegate as? AppDelegate
        // from the AppDelegate, obtain a reference to the Model data:
        //self.myFlashCardModel = self.appDelegate?.myFlashCardModel
        
        self.questionTextField.text = "this is where the Question will appear"
        self.answerTextField.text = "this is where the Answer will appear"
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

