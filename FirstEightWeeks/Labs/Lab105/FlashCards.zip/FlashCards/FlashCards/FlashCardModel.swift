//
//  FlashCardModel.swift
//  FlashCards
//
//  Created by Philip, Angely on 9/7/16.
//  Copyright © 2016 A290. All rights reserved.
//

import Foundation

class FlashCardModel {
    
    var questionsArray =
        [0: "What is your name?",
         1: "What is 42?",
         2: "What is the color of the sky?"]
    var answersArray =
        [0: "My name is not important",
         1: "It is 6 times 7",
         2: "Kind of gray today"]
    
    var currentQuestionIndex = 0
    
    init () {}
    
    func getNextQuestion() -> String{
        currentQuestionIndex += 1
        if (currentQuestionIndex>=questionsArray.count) {
            currentQuestionIndex = 0
        }
        return questionsArray[currentQuestionIndex]!
    }
    
    func getAnswer() -> String {
        return answersArray[currentQuestionIndex]!
    }
}