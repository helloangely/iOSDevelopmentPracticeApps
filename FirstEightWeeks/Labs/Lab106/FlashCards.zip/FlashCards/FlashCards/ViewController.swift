//
//  ViewController.swift
//  FlashCards
//
//  Created by Philip, Angely on 8/31/16.
//  Copyright © 2016 A290. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    // add model
    let myFlashCardModel = FlashCardModel()
    
    // no question asked 
    var aQuestionIsAsked = false
    
    @IBOutlet var answerLabel: UILabel! // ! handles when user closes app, and there is no longer a label. when not needed?
    @IBOutlet var questionLabel: UILabel! // ! means creating variable that may or may not have a value
    
    @IBAction func showQuestion(sender: AnyObject) {
        let lQuestion : String = myFlashCardModel.getNextQuestion()
        self.questionLabel.text = lQuestion
        self.answerLabel.text = "(....try guessing)"
    }
    
    @IBAction func showAnswer(sender: AnyObject) {
        let lAnswer : String = myFlashCardModel.getAnswer()
        self.answerLabel.text = lAnswer
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

