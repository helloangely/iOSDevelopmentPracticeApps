//
//  ViewController.swift
//  Hello Touch anphilip
//
//  Created by Philip, Angely on 9/14/16.
//  Copyright © 2016 Philip, Angely. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var messageLabel:UILabel!
    @IBOutlet var tapsLabel:UILabel!
    @IBOutlet var touchesLabel:UILabel!
    
    func updateLabelsFromTouches(touches: NSSet) {
        let theTouchObject = touches.anyObject() as! UITouch
        let theNumOfTaps = theTouchObject.tapCount
        let theTapsMessage = "\(theNumOfTaps) taps detected in sequence"
        self.tapsLabel.text = theTapsMessage
        let theNumOfTouches = touches.count
        let theTouchesMessage = "\(theNumOfTouches) touches detected at once"
        self.touchesLabel.text = theTouchesMessage
        
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        if let firstTouch = touches.first {
            let gestureStartPoint = firstTouch.locationInView(self.view)
            self.messageLabel.text = "Touches Began at \(gestureStartPoint.x), \(gestureStartPoint.y)"
        }
        updateLabelsFromTouches(event!.allTouches()!)
    }
    
    override func touchesEnded(touches: Set<UITouch>, withEvent event: UIEvent?) {
        if let firstTouch = touches.first {
            let gestureStartPoint = firstTouch.locationInView(self.view)
            self.messageLabel.text = "Touches Ended at \(gestureStartPoint.x), \(gestureStartPoint.y)"
        }
        updateLabelsFromTouches(event!.allTouches()!)
    }
    
    override func touchesCancelled(touches: Set<UITouch>?, withEvent event: UIEvent?) {
        self.messageLabel.text = "Touches Cancelled"
        updateLabelsFromTouches(event!.allTouches()!)
    }
    
    override func touchesMoved(touches: Set<UITouch>, withEvent event: UIEvent?) {
        if let firstTouch = touches.first {
            let gestureStartPoint = firstTouch.locationInView(self.view)
            self.messageLabel.text = "Touches Moved at \(gestureStartPoint.x), \(gestureStartPoint.y)"
        }
        updateLabelsFromTouches(event!.allTouches()!)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

