//
//  Constants.swift
//  test
//
//  Created by Philip, Angely on 10/5/16.
//  Copyright © 2016 Philip, Angely. All rights reserved.
//

import Foundation

let teamLeaderKey = "leader"