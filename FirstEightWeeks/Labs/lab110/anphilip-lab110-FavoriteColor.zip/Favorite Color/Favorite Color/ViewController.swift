//
//  ViewController.swift
//  Favorite Color
//
//  Created by Walter Babcock on 9/23/16.
//  Copyright © 2016 Walter Babcock. All rights reserved.
//


import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var FavoriteView: UIView!
    @IBOutlet weak var BuggyLabel: UILabel!
    @IBOutlet weak var AccurateLabel: UILabel!
    
    var buggyCount = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        if(pickerVariables.chosenColor != "") {
            mainVariables.favoriteColor = pickerVariables.chosenColor
        }
        FavoriteView.backgroundColor = UIColorFromRGB(mainVariables.favoriteColor, alpha: 1)
        
        BuggyLabel.text = "Buggy Count: " + String(buggyCount)
        AccurateLabel.text = "Accurate Count: " + String(mainVariables.accurateCount)
        buggyCount += 1
        mainVariables.accurateCount += 1
        
        if(mainVariables.user == nil) {
            mainVariables.user = User()
        }
    }
    
    
    @IBAction func ChangeColorClick(sender: AnyObject) {
        pickerVariables.sendingController = "Home"
        let mainStoryboard = UIStoryboard(name: "Main", bundle: NSBundle.mainBundle())
        let vc : UIViewController = mainStoryboard.instantiateViewControllerWithIdentifier("ColorPicker")
        self.presentViewController(vc, animated: true, completion: nil)
    }
    
    
    @IBAction func ShowUserInfo(sender: AnyObject) {
        let message = "Name: " + mainVariables.user!.name + "\r\n\r\nAge: " + mainVariables.user!.age + "\r\n\r\nHometown: " + mainVariables.user!.hometown
        let alert = UIAlertController(title: "User Info", message: message, preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default, handler: {(UIAlertAction) in
            
        }))
        alert.addAction(UIAlertAction(title: "Update Info", style: UIAlertActionStyle.Default, handler: {(UIAlertAction) in
            self.showUpdateAlert()
        }))
        self.presentViewController(alert, animated: true, completion: nil)
    }
    
    
    func showUpdateAlert() {
        let alert = UIAlertController(title: "Update User Info", message: "", preferredStyle: UIAlertControllerStyle.Alert)
        alert.addTextFieldWithConfigurationHandler({ (textField) -> Void in
            textField.text = mainVariables.user!.name
        })
        alert.addAction(UIAlertAction(title: "Submit", style: UIAlertActionStyle.Default, handler: {(UIAlertAction) in
            let textField = alert.textFields![0] as UITextField
            mainVariables.user!.name = textField.text!
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertActionStyle.Default, handler: {(UIAlertAction) in
        }))
        self.presentViewController(alert, animated: true, completion: nil)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

