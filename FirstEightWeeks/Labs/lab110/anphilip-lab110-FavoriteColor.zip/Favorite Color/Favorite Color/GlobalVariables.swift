//
//  GlobalVariables.swift
//  Favorite Color
//
//  Created by Walter Babcock on 9/23/16.
//  Copyright © 2016 Walter Babcock. All rights reserved.
//

import Foundation

struct mainVariables {
    static var accurateCount = 0
    static var favoriteColor = "000000"
    static var user : User?
}


class User : NSObject, NSCoding {
    var name : String
    var age : String
    var hometown : String
    
    override init() {
        name = "John Doe"
        age = "20"
        hometown = "Popular Bluff"
    }
    
    required init (coder decoder: NSCoder) {
        self.name = decoder.decodeObjectForKey("name") as! String
        self.age = decoder.decodeObjectForKey("age") as! String
        self.hometown = decoder.decodeObjectForKey("hometown") as! String
    }
    
    func encodeWithCoder(coder: NSCoder) {
        coder.encodeObject(self.name, forKey: "name")
        coder.encodeObject(self.age, forKey: "age")
        coder.encodeObject(self.hometown, forKey: "hometown")
    }
    
}



