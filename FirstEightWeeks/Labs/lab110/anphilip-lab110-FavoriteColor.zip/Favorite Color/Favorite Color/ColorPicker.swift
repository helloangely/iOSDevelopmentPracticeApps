//
//  ColorPicker.swift
//  PressBoard
//
//  Created by PAR on 1/11/16.
//  Copyright © 2016 Babcock. All rights reserved.
//


struct pickerVariables {
    static var colorList = [String]()
    static var chosenColor = ""
    static var sendingController = ""
}



import UIKit

class ColorPickerViewController: UIViewController {
    
    var preview = UIView()
    var viewList = [UIView]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewDidAppear(animated: Bool) {
        if(pickerVariables.colorList.count == 0)
        {
            do
            {
                let path = NSBundle.mainBundle().pathForResource("colors", ofType: "txt")
                let t = try (NSString(contentsOfFile: path!, encoding: NSUTF8StringEncoding) as String)
                var text = t as NSString
                while(indexOf(text, find: "#FINALEND#") > 0)
                {
                    pickerVariables.colorList.append(text.substringToIndex(indexOf(text, find:"\n")))
                    text = text.substringFromIndex(indexOf(text, find:"\n") + 1)
                }
            }
            catch
            {
                
            }
        }
        let width = self.view.frame.width / 12
        var yPos = ((self.view.frame.height - (width * 16)) / 2) + width
        var xPos = width
        
        let touch = UILongPressGestureRecognizer(target: self, action: "pickStart:")
        touch.minimumPressDuration = 0.01
        self.view.addGestureRecognizer(touch)
        
        self.preview = UIView((frame: CGRectMake(width, 2 * width, width*10, width)))
        self.preview.layer.borderWidth = 1
        self.preview.layer.cornerRadius = 3
        self.preview.layer.borderColor = UIColor.blackColor().CGColor
        self.preview.layer.backgroundColor = UIColor.clearColor().CGColor
        self.view.addSubview(self.preview)
        
        for(var i = 0; i<pickerVariables.colorList.count; i++)
        {
            if(i % 10 == 0 && i != 0)
            {
                xPos = width
                yPos += width
            }
            let button = UIView((frame: CGRectMake(xPos, yPos, width, width)))
            button.layer.borderWidth = 2
            button.layer.borderColor = UIColor.whiteColor().CGColor
            button.layer.backgroundColor = UIColorFromRGB(pickerVariables.colorList[i], alpha: 1).CGColor
            button.layer.cornerRadius = 0
            self.viewList.append(button)
            self.view.addSubview(button)
            xPos += width
        }
    }
    
    func pickStart(recognizer: UILongPressGestureRecognizer)
    {
        let state = recognizer.state
        let p = recognizer.locationInView(recognizer.view!.window)
        switch(state)
        {
        case UIGestureRecognizerState.Began:
            for(var i = 0; i<self.viewList.count; i++)
            {
                if(self.viewList[i].frame.contains(p))
                {
                    self.preview.layer.backgroundColor = UIColorFromRGB(pickerVariables.colorList[i]).CGColor
                    break
                }
            }
            break
        case UIGestureRecognizerState.Changed:
            for(var i = 0; i<self.viewList.count; i++)
            {
                if(self.viewList[i].frame.contains(p))
                {
                    self.preview.layer.backgroundColor = UIColorFromRGB(pickerVariables.colorList[i]).CGColor
                    break
                }
            }
            break
        case UIGestureRecognizerState.Ended:
            for(var i = 0; i<self.viewList.count; i++)
            {
                if(self.viewList[i].frame.contains(p))
                {
                    pickerVariables.chosenColor = pickerVariables.colorList[i]
                    let mainStoryboard = UIStoryboard(name: "Main", bundle: NSBundle.mainBundle())
                    let vc : UIViewController = mainStoryboard.instantiateViewControllerWithIdentifier(pickerVariables.sendingController)
                    self.presentViewController(vc, animated: true, completion: nil)
                    break
                }
            }
            break
        default:
            break
        }
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}


func indexOf(text:NSString, find:String) -> Int {
    if(text.rangeOfString(find).toRange() != nil) {
        return text.rangeOfString(find).toRange()!.startIndex as Int
    }
    else {
        return -1
    }
}


func UIColorFromRGB( colorCode: String, alpha: Float = 1.0) -> UIColor {
    
    let colorCode = colorCode.stringByReplacingOccurrencesOfString("#", withString: "", options: NSStringCompareOptions.LiteralSearch, range: nil)
    let scanner = NSScanner(string:colorCode)
    var color:UInt32 = 0;
    scanner.scanHexInt(&color)
    
    let mask = 0x000000FF
    let r = CGFloat(Float(Int(color >> 16) & mask)/255.0)
    let g = CGFloat(Float(Int(color >> 8) & mask)/255.0)
    let b = CGFloat(Float(Int(color) & mask)/255.0)
    
    return UIColor(red: r, green: g, blue: b, alpha: CGFloat(alpha))
}






