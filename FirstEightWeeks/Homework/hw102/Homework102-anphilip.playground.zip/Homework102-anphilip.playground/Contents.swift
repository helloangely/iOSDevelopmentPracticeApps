// Angely Philip anphilip
// Homework 102
// A290 / Spring 2016
// Github submit 9/11 2:55pm 

import UIKit


// A switch/case

let glassesStatus = "new"
    
switch glassesStatus {
case "scratched":
    let glassesOrder = "Add scratch resistant coating."
case "cant read":
    let glassesOrder = "Take a vision test."
default:
    let glassesOrder = "Enjoy your new glasses."
    // Error: switch must be exhuastive, consider adding a defualt clause
}


// B twoThings
// twoThings : float float -> tuple
// takes in two floats and returns sum and product as 2 value tuple

func twoThings(num1: Float, num2: Float) -> (numSum: Float, numProd: Float ) {
    return (num1+num2, num1*num2)
}

// example use of twoThings
print(
    twoThings(2.234, num2: 2.333),
    twoThings(2.234, num2: 4.444),
    twoThings(2.234, num2: 1.234) )

// C for-loops


// dictionary values are arrays of integers, with strings as the key
let interestingNumbers = [
    "Prime": [2,3,5,7,11,13],
    "Fibonacci": [1,1,2,3,5,8],
    "Square": [1,4,9,16,25]
    ]
    
// largest is int and kindLargest is string
var largest = 0
var kindLargest = ""
    
// for loop goes through every key in the dictionary
for (kind, numbers) in interestingNumbers {
    // for loop goes through every element in the value and finds the greatest value and assigns kind
    for number in numbers {
        if number > largest {
            largest = number
            kindLargest = kind
        }
    }
}
    
print("the larget number is \(largest) and it's kind is \(kindLargest)")


// D class


// class HW102 has two parameters which are two numbers to be calculated 
// class HW102 has three methods: glassStat, twoThings, and interestNums

class HW102 {
    var num1: Float = 0.0
    var num2: Float = 0.0
    

// A switch/case

    func glassStat() -> String {
        let glassesStatus = "new"

        switch glassesStatus {
            case "scratched":
                return "Add scratch resistant coating."
            case "cant read":
                return "Take a vision test."
            default:
                return "Enjoy your new glasses."
            // Error: switch must be exhuastive, consider adding a defualt clause
        }
    }


    // B twoThings
    // twoThings : float float -> tuple
    // takes in two floats and returns sum and product as 2 value tuple

    func twoThings() -> (numSum: Float, numProd: Float ) {
        return (self.num1+self.num2, self.num1*self.num2)
    }


    // C for-loops

    func interestNums() -> String {
        // dictionary values are arrays of integers, with strings as the key
        let interestingNumbers = [
            "Prime": [2,3,5,7,11,13],
            "Fibonacci": [1,1,2,3,5,8],
            "Square": [1,4,9,16,25]
            ]

        // largest is int and kindLargest is string
        var largest = 0
        var kindLargest = ""

        // for loop goes through every key in the dictionary
        for (kind, numbers) in interestingNumbers {
            // for loop goes through every element in the value and finds the greatest value and assigns kind
            for number in numbers {
                if number > largest {
                    largest = number
                    kindLargest = kind
                }
            }
        }

        return "the larget number is \(largest) and it's kind is \(kindLargest)"

        }
}

// initialize class HW102
var hw = HW102()

// initialize variables and call twoThings method
hw.num1 = 2.333
hw.num2 = 3.444
hw.twoThings()

hw.num1 = 234.33
hw.num2 = 444.32
hw.twoThings()

// call glassStat and interestNums method
hw.glassStat()
hw.interestNums()


