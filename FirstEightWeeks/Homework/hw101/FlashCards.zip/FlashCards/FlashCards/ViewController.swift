//
//  ViewController.swift
//  FlashCards
//
//  Created by Philip, Angely on 8/31/16.
//  Copyright © 2016 A290. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var answerLabel: UILabel! // ! handles when user closes app, and there is no longer a label. when not needed?
    @IBOutlet var questionLabel: UILabel! // ! means creating variable that may or may not have a value
    
    @IBAction func showQuestion(sender: AnyObject) {
        self.questionLabel.text = "How old are you?"
        self.answerLabel.text = "(try guessing....)"
    }
    
    @IBAction func showAnswer(sender: AnyObject) {
        self.answerLabel.text = "I'm 10 years old."
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

