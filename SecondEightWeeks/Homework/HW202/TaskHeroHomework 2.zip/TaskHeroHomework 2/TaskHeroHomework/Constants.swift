//
//  Constants.swift
//  TaskHeroHomework
//
//  Created by Miller, Jacob Paul on 10/12/16.
//  Copyright © 2016 Jake Miller. All rights reserved.
//

import Foundation
let nameKey = "namekey"
