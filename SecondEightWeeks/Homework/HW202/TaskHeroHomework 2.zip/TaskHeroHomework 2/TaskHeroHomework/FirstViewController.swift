//
//  FirstViewController.swift
//  TaskHeroHomework
//
//  Created by Jake Miller on 10/10/16.
//  Copyright © 2016 Jake Miller. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet var tableTask: UITableView!
    @IBOutlet var nameLabel:UILabel!
    
    func refreshFields(){
        let myDefaults = NSUserDefaults.standardUserDefaults()
        var text = myDefaults.stringForKey(nameKey)
        if (text == "") {
            text = "Task List"
        }
        else {
            text = text! + "'s Task List"
        }
        nameLabel.text = text
        myDefaults.synchronize()
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        refreshFields()
        tableTask.reloadData()
    }
    
    func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath){
        if(editingStyle == UITableViewCellEditingStyle.Delete){
            taskManager.tasks.removeAtIndex(indexPath.row)
            tableTask.reloadData()
        }
    }
    

    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return taskManager.tasks.count
    }

    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell{
        let cell: UITableViewCell = UITableViewCell(style: UITableViewCellStyle.Subtitle, reuseIdentifier: "Default")
        
        cell.textLabel!.text = taskManager.tasks[indexPath.row].category
        cell.detailTextLabel!.text = taskManager.tasks[indexPath.row].description
        
        return cell
    }
}

