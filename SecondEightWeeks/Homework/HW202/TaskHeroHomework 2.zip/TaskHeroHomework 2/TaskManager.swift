//
//  TaskManager.swift
//  TaskHeroHomework
//
//  Created by Jake Miller on 10/10/16.
//  Copyright © 2016 Jake Miller. All rights reserved.
//

import UIKit

var taskManager: TaskManager = TaskManager()

struct task{
    var category = "No Category"
    var description = "No Description"
    var duration = "No Duration"
    // var dueDate = "No Due Date"
}

class TaskManager: NSObject {
    
    var tasks: [task] = []
    
    func addTask(category: String, description: String, duration: String){
        if Int(duration) <= 2 {
            tasks.append(task(category: category, description: description, duration: duration))
        }
        else {
            print("Duration too high, max is 2 hours")
        }
    }
    
}
