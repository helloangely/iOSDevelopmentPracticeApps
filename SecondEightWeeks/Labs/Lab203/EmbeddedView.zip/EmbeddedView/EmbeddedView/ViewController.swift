//
//  ViewController.swift
//  EmbeddedView
//
//  Created by Philip, Angely on 10/24/16.
//  Copyright © 2016 Philip, Angely. All rights reserved.
//

import UIKit

protocol ButtonDelegate: class {
    func buttonPressed(num: Int)
}

class ViewController: UIViewController {
    
    @IBOutlet weak var inputTextField: UITextField!
    @IBOutlet weak var chatWindow: UITextView!
    @IBAction func buttonSend(sender: AnyObject) {}
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

class MasterViewController: UIViewController {
    
    weak var delegate: ButtonDelegate?
    
    @IBAction func button1(sender: AnyObject) {
        self.delegate?.buttonPressed(1)
    }
    @IBAction func button2(sender: AnyObject) {
        self.delegate?.buttonPressed(2)
    }
    @IBAction func button3(sender: AnyObject) {
        self.delegate?.buttonPressed(3)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}


class DetailViewController: UIViewController, ButtonDelegate {
    
    @IBOutlet var label1: UILabel!
    
    func buttonPressed(num: Int) {
        label1.text = "Hello from button #" + String(num)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}