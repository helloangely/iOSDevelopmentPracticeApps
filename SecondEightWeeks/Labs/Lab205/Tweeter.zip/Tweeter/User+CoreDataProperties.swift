//
//  User+CoreDataProperties.swift
//  Tweeter
//
//  Created by Philip, Angely on 11/2/16.
//  Copyright © 2016 Philip, Angely. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

import Foundation
import CoreData

extension User {

    @NSManaged var avatarID: String?
    @NSManaged var name: String?
    @NSManaged var password: String?
    @NSManaged var username: String?
    @NSManaged var postsList: NSSet?

}
