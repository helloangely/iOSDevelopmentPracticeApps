//
//  ViewController.swift
//  Tweeter
//
//  Created by Philip, Angely on 11/2/16.
//  Copyright © 2016 Philip, Angely. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

