//
//  User.swift
//  Tweeter
//
//  Created by Philip, Angely on 11/2/16.
//  Copyright © 2016 Philip, Angely. All rights reserved.
//

import Foundation
import CoreData


class User: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
