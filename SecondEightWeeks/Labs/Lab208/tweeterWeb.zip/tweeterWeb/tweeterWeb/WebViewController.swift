//
//  WebViewController.swift
//  tweeterWeb
//
//  Created by Mitja Hmeljak on 2016-04-20.
//  Copyright © 2016 A290 Spring 2016. All rights reserved.
//

import UIKit

class WebViewController: UIViewController, UIWebViewDelegate {

    
    @IBOutlet weak var iWebView: UIWebView! // displays search results
    var detailItem: NSURL?  // URL that will be displayed

    
    
    // ------------------------------------------------------------
    // MARK: - UIViewController class methods:
    // ------------------------------------------------------------
    
    // instance variable to store a reference to the app Delegate:
    var iAppDelegate: AppDelegate? = nil
    
    
    // instance variable to store a reference to our Model class:
    var iModel: TweeterModel? = nil
    
    // configure DetailViewController as the webView's delegate
    override func viewDidLoad() {
        super.viewDidLoad()
        self.iWebView.delegate = self
        
        // now obtain a reference to the App Delegate...
        self.iAppDelegate = UIApplication.sharedApplication().delegate as? AppDelegate
        
        // ..and a reference to our app's main model instance:
        self.iModel = self.iAppDelegate?.iModel

        }
    
    // when view appears, the url is loaded in the UIWebView.
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        
        self.detailItem = NSURL(string: (self.iModel?.detailItem)!)
        
        if let url = self.detailItem {
            iWebView.loadRequest(NSURLRequest(URL: url))
        }
        
    }
    
    // stop page load and hide network activity indicator when
    // returning to MasterViewController
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
        UIApplication.sharedApplication()
            . networkActivityIndicatorVisible = false
        iWebView.stopLoading()
    }
    
    // when loading starts, show network activity indicator
    func webViewDidStartLoad(webView: UIWebView) {
        UIApplication.sharedApplication()
            . networkActivityIndicatorVisible = true
    }
    
    // hide network activity indicator when page finishes loading
    func webViewDidFinishLoad(webView: UIWebView) {
        UIApplication.sharedApplication()
            . networkActivityIndicatorVisible = false
    }
    
    // webView...didFailLoadWithError  is called if a webpage fails to properly load in the UIWebView.
    func webView(webView: UIWebView, didFailLoadWithError error: NSError?) {
            webView.loadHTMLString(
                "<html><body><p>An error occurred when performing " +
                    "the Twitter search: " + error!.description +
                "</body></html>", baseURL: nil)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
