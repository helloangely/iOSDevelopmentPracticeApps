//
//  TweeterTableViewController.swift
//  tweeterTableCoreData

//  modeled after sample code in the book
//  "Core Data by Tutorials Second Edition: iOS 9 and Swift 2 Edition"
//  http://www.amazon.com/Core-Data-Tutorials-Second-Edition/dp/1942878109

//
//  Created by Mitja Hmeljak on 2016-04-06.
//  Copyright © 2016 A290 Spring 2016. All rights reserved.
//

// import UIKit for UITableViewDataSource, etc.:
import UIKit

// import CoreData for NSManagedObject, etc.:
import CoreData

// note about variable/property naming convention in this file:
// variable names with an "i" prefix indicate instance variables or properties
// variable names with an "l" prefix indicate variables that are local to a method or function
// variable names with a "g" prefix indicate global variables


// we implement the UITableViewDataSource protocol, since we want to
//  mediate the application’s data model for a UITableView:
class TweeterTableViewController: UIViewController, UITableViewDataSource {
    
    // the table view that this ViewController controls:
    @IBOutlet weak var iTableView: UITableView!
    
    // instance variable to store a reference to the app Delegate:
    var iAppDelegate: AppDelegate? = nil
    
    // instance variable to store a reference to the managed Object Context:
    var iManagedContext: NSManagedObjectContext? = nil

    // instance variable to store a reference to our Model class:
    var iModel: TweeterModel? = nil

    
    // user interface to create a new User and add it to our collection of users:
    @IBAction func addUser(sender: AnyObject) {
        
        // new user data is input from an UIAlertController:
        // http://developer.apple.com/library/ios/documentation/UIKit/Reference/UIAlertController_class/
        
        let lAlert = UIAlertController(
            title: "New Contact",
            message: "enter username, latitude, longitude, and URL:",
            preferredStyle: UIAlertControllerStyle.Alert)
        
        // the alert controller may end with "Cancel" or with "Save":
        
        let lCancelAction = UIAlertAction(
            title: "Cancel",
            style: UIAlertActionStyle.Default,
            handler: {
                (action: UIAlertAction) -> Void in
                // do nothing if "Cancel" is pressed
            }
        )
        
        let lSaveAction = UIAlertAction(
            title: "Save",
            style: UIAlertActionStyle.Default,
            handler: {
                (action: UIAlertAction) -> Void in
                
                // get text input from user:
                let usernameTextFromUser = lAlert.textFields![0]

                // get text input from user:
                let latitudeTextFromUser = lAlert.textFields![1]

                // get text input from user:
                let longitudeTextFromUser = lAlert.textFields![2]
                
                // get text input from user:
                let urlTextFromUser = lAlert.textFields![3]

                // save username for new user contact:
                self.iModel!.createNewUserEntity(
                    usernameTextFromUser.text!,
                    pLatitudeText: latitudeTextFromUser.text!,
                    pLongitudeText: longitudeTextFromUser.text!,
                    urlText: urlTextFromUser.text!)
                
                // if we were using a standard table:
                // self.iUsers.append(inputTextFromUser!.text!)
                
                // ask the table to redisplay its content:
                self.iTableView.reloadData()
            }
        )
        
        // add the two actions as buttons to the alert controller:
        lAlert.addAction(lCancelAction)
        lAlert.addAction(lSaveAction)
        
        // we also need an input text field:
        lAlert.addTextFieldWithConfigurationHandler {
            (textField: UITextField) -> Void in
            // configure the input text field - nothing to do.
        }

        // we also need an input text field:
        lAlert.addTextFieldWithConfigurationHandler {
            (textField: UITextField) -> Void in
            // configure the input text field - nothing to do.
        }

        // we also need an input text field:
        lAlert.addTextFieldWithConfigurationHandler {
            (textField: UITextField) -> Void in
            // configure the input text field - nothing to do.
        }
        
        // we also need an input text field:
        lAlert.addTextFieldWithConfigurationHandler {
            (textField: UITextField) -> Void in
            // configure the input text field - nothing to do.
        }
        
        // present the alert to the user:
        presentViewController(
            lAlert, animated: true, completion: nil)
    }  // end of func addUser()
    
    
    // ------------------------------------------------------------
    // MARK: - UITableViewDataSource protocol methods:
    // ------------------------------------------------------------
    
    func tableView(tableView: UITableView,
        numberOfRowsInSection section: Int) -> Int {
            // the table will have as many rows as there are users:
            return self.iModel!.iUsers.count
    }
    
    func tableView(
        tableView: UITableView,
        cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
            
            // create a single cell for the table, displaying a username:
            let lCell = self.iTableView.dequeueReusableCellWithIdentifier("TweeterCell")
            
            // obtain the username by querying one element in the iUsers NSManagedObject...
            let lUser = self.iModel!.iUsers[indexPath.row]
            // ...using the key-value coding defined in our .xcdatamodeld file:
            lCell!.textLabel!.text = lUser.valueForKey("username") as? String
            lCell!.detailTextLabel!.text =
            "\(lUser.valueForKey("latitude") as! Float), \(lUser.valueForKey("longitude") as! Float)"
            
            // return the cell we just created:
            return lCell!
    }
    
    
    // ------------------------------------------------------------
    // MARK: - UIViewController class methods:
    // ------------------------------------------------------------
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        // the main view has just loaded:
        // register a class (the standard UITableViewCell.self class)
        // for use in creating new table cells for the iTableView table:
        self.iTableView.registerClass(
            UITableViewCell.self,
            forCellReuseIdentifier: "Cell")
        
        // now obtain a reference to the App Delegate...
        self.iAppDelegate = UIApplication.sharedApplication().delegate as? AppDelegate
        
        // ..and a reference to our app's main model instance:
        self.iModel = self.iAppDelegate?.iModel
        
        // ask the model to obtain all entities representing Users:
        self.iModel!.fetchEntities("User")
        
        // when the view is loaded, fill the table with all Users data
        //   that can be retrieved from the Managed Object Context persistent storage
    } // end of func viewDidLoad()
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
} // end of class TweeterTableViewController

