//
//  TweeterModel.swift
//  tweeterCoreLocation
//
//  Created by Mitja Hmeljak on 2016-04-13.
//  Copyright © 2016 A290 Spring 2016. All rights reserved.
//

import UIKit
import CoreData


// we implement the UITableViewDataSource protocol, since we want to
//  mediate the application’s data model for a UITableView:
class TweeterModel: NSObject {
    var detailItem = "https://www.google.com"
    
    // instance variable to store a reference to the app Delegate:
    var iAppDelegate: AppDelegate? = nil
    
    // instance variable to store a reference to the managed Object Context:
    var iManagedContext: NSManagedObjectContext? = nil

    // if we didn't have persistent storage, we would just keep data in memory:
    //  var iUsers = [String]()
    // with Core Data, all data is stored in an NSManagedObject:
    var iUsers = [NSManagedObject]()
    
    override init() {
        
        // now obtain a reference to the App Delegate...
        self.iAppDelegate = UIApplication.sharedApplication().delegate as? AppDelegate
        
        // ... from the App Delegate, get a reference to the Managed Object Context:
        self.iManagedContext = self.iAppDelegate?.managedObjectContext
        
        let lFetchRequest = NSFetchRequest(entityName: "User")
        // finally obtain all entities representing Users from
        //   the Managed Object Context persistent storage:
        do {
            // obtain the array of objects that meet the criteria
            //   specified by request,
            //   fetched from the receiver,
            //   and from the persistent stores associated with the
            //   receiver’s persistent store coordinator:
            let lArrayOfObjects = try self.iManagedContext!.executeFetchRequest(lFetchRequest)
            // keep the obtained array of objects in an instance variable:
            self.iUsers = lArrayOfObjects as! [NSManagedObject]
        } catch let lError as NSError {
            // if anything went wrong while trying to save, report the error:
            NSLog("Error in fetching \(lError), \(lError.userInfo)")
        }

        
    }
    
    // create a Core Data entity for a new User,
    //   and save it to the Managed Object Context:
    func createNewUserEntity(
        pUserName: String,
        pLatitudeText: String,
        pLongitudeText: String,
        urlText: String) {
            
            // prepare a description of a Core Data entity,
            //   as specified in our .xcdatamodeld file:
            let lEntityDescription =  NSEntityDescription.entityForName("User",
                inManagedObjectContext:self.iManagedContext!)
            
            // create a managed object
            //   representing one User entity in our Core Data collection:
            let lUser = NSManagedObject(entity: lEntityDescription!,
                insertIntoManagedObjectContext: self.iManagedContext)
            
            // set the key-value coding defined in our .xcdatamodeld file, i.e.
            //   assign:
            //     to the lUser entity just created,
            //     at the "username" key,
            //     the value found in pUserName
            lUser.setValue(pUserName, forKey: "username")
            
            let lLatitude = NSString(string: pLatitudeText).floatValue
            let lLongitude = NSString(string: pLongitudeText).floatValue
            
            lUser.setValue(lLatitude, forKey: "latitude")

            lUser.setValue(lLongitude, forKey: "longitude")
        
            lUser.setValue(urlText, forKey: "url")
            self.detailItem = urlText
            
            // finally save the new entity representing a new User
            //   into the Managed Object Context
            do {
                try self.iManagedContext!.save()
                // if the new entity saved correctly to the Managed Object Context,
                //   also add it to the instance variable, for displaying it in the table:
                self.iUsers.append(lUser)
            } catch let lError as NSError  {
                // if anything went wrong while trying to save, report the error:
                NSLog("Error in saving \(lError), \(lError.userInfo)")
            }
            
    } // end of func createNewUserEntity()
    
    
    
    func fetchEntities(pEntityName: String) {
        // first prepare the type of fetch request, i.e.
        //   find all entities named "User":
        let lFetchRequest = NSFetchRequest(entityName: pEntityName)
        
        
        // finally obtain all entities representing Users from
        //   the Managed Object Context persistent storage:
        do {
            // obtain the array of objects that meet the criteria
            //   specified by request,
            //   fetched from the receiver,
            //   and from the persistent stores associated with the
            //   receiver’s persistent store coordinator:
            let lArrayOfObjects = try self.iManagedContext!.executeFetchRequest(lFetchRequest)
            // keep the obtained array of objects in an instance variable:
            self.iUsers = lArrayOfObjects as! [NSManagedObject]
        } catch let lError as NSError {
            // if anything went wrong while trying to save, report the error:
            NSLog("Error in fetching \(lError), \(lError.userInfo)")
        }
    }


}