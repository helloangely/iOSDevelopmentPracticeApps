//
//  TaskManager.swift
//  TaskHeroHomework
//
//  Created by Jake Miller on 10/10/16.
//  Copyright © 2016 Jake Miller. All rights reserved.
//

import UIKit

var taskManager: TaskManager = TaskManager()

struct task{
    var category = "No Category"
    var description = "No Description"
}

class TaskManager: NSObject {
    
    var tasks: [task] = []
    
    func addTask(category: String, description: String){
        tasks.append(task(category: category, description: description))
    }
}
