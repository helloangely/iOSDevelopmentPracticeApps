//
//  Eliza.swift
//  Eliza.swift
//
//  Created by Miller, Jacob Paul on 10/19/16.
//  Copyright © 2016 Miller, Jacob Paul. All rights reserved.
//

import Foundation

class Eliza{
    
    init(){}
    
    
    let greetingWords: [String] = ["hello", "howdy", "hi", "greetings"]
    let farewellWords: [String] = ["goodbye", "later"]
    let greetCount = 0
    let farewellCount = 0
    let randomIndex = Int(arc4random_uniform(UInt32(self.count)))
    
    func getResponse(pUserInput: String) -> String {
        let InputLowerCase = pUserInput.lowercaseString
        let InputWithoutNewline = InputLowerCase.componentsSeparatedByString("\n")

        let InputWords = InputWithoutNewline[0].componentsSeparatedByString(" ")
        
        for word in InputWords{
            if(greetingWords.contains(word)){
                greetCount + 1
            }
            else if(farewellWords.contains(word)){
                farewellCount + 1
            }
            
            
        }
        
        if greetCount > farewellCount {
            return (greetingWords[randomIndex])
        }
    }

    func getInputFromKeyboard() -> String {
        let IKeyboard = NSFileHandle.fileHandleWithStandardInput()
        let IInputData = IKeyboard.availableData
        return NSString(data: IInputData, encoding: NSUTF8StringEncoding)! as String
    }
    
}