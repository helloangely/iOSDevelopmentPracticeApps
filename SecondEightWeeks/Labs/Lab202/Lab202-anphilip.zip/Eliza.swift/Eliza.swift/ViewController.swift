//
//  ViewController.swift
//  Eliza.swift
//
//  Created by Miller, Jacob Paul on 10/19/16.
//  Copyright © 2016 Miller, Jacob Paul. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    let myEliza: Eliza = Eliza()
    
    @IBOutlet weak var inputTextField: UITextField!
    @IBOutlet weak var chatWindow: UITextView!
    
    @IBAction func buttonSend(sender: AnyObject) {
        
        let response = myEliza.getResponse(inputTextField.text!)
        
        chatWindow.text = chatWindow.text + "User:" + inputTextField.text! + "\n" + "Eliza:" + (response)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

