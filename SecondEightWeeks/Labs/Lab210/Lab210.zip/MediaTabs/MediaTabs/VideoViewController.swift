//
//  VideoViewController.swift
//  MediaTabs
//
//  Created by Mitja Hmeljak on 2016-04-18.
//  Copyright © 2016 B481 Spring 2016. All rights reserved.
//

import UIKit

class VideoViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

