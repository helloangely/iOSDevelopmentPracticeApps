//
//  TimerViewController.swift
//  TaskHeroHomework
//
//  Created by Philip, Angely on 12/1/16.
//  Copyright © 2016 Jake Miller. All rights reserved.
//

import UIKit

class TimerViewController: UIViewController, UITextFieldDelegate {
    var indexPos: Int = 0
   @IBOutlet weak var descripLabel: UILabel!
   @IBOutlet weak var dueLabel: UILabel!
   @IBOutlet var countingLabel: UILabel!
   @IBOutlet var titleLabel: UILabel!
   var progressView: UIProgressView?
    
    // set up timer
    var timer = NSTimer()
    var counter = 0
    var progressValue = Float(0)
    
   @IBAction func pauseTask(sender: AnyObject) {
        timer.invalidate()
    }
    
   @IBAction func startTask(sender: AnyObject) {
    if !timer.valid {
        let durationSeconds = Int(taskManager.tasks[indexPos].durHours)! * 3600 + Int(taskManager.tasks[indexPos].durMins)! * 60
        counter = durationSeconds
       
      
        progressView?.setProgress(Float(counter), animated: true)
        progressValue = (self.progressView?.progress)!
        
        timer = NSTimer.scheduledTimerWithTimeInterval(1, target:self, selector: #selector(TimerViewController.updateCounter), userInfo: nil, repeats: true)
        flag = true
       

        
    }
    }
    
    func updateCounter() {
        if counter > 0 {
            counter = counter - 1
            let hrs = counter/3600
            let mins = (counter%3600)/60
            let secs = (counter%3600)%60
            countingLabel.text = String(hrs) + " hours, " + String(mins) + " minutes and " + String(secs) + " seconds"
        }
    }
    
    //begin progress bar
    func addControls() {
        // Create Progress View Control
        progressView = UIProgressView(progressViewStyle: UIProgressViewStyle.Default)
        progressView?.center = self.view.center
        view.addSubview(progressView!)
    }
   
    //update bar
    func updateProgress() {
        
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        addControls()
        
        // udpate labels
        descripLabel.text = taskManager.tasks[indexPos].descrip
        titleLabel.text = taskManager.tasks[indexPos].category
        let formatter = NSDateFormatter()
        formatter.dateStyle = NSDateFormatterStyle.FullStyle
        formatter.timeStyle = .ShortStyle
        let dateString = formatter.stringFromDate(taskManager.tasks[indexPos].dueDate)
        dueLabel.text = "Due: " + dateString

    }
    

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}