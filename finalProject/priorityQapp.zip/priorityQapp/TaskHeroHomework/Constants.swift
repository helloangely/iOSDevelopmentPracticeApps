//
//  Constants.swift
//  TaskHeroHomework
//
//  Copyright © 2016 qApp. All rights reserved.
//

import Foundation
let nameKey = "namekey"
var flag: Bool = false
