//
//  SecondViewController.swift
//  TaskHeroHomework
//
//  Copyright © 2016 qApp. All rights reserved.
//

import UIKit

class AddTaskViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet var textTask: UITextField!
    @IBOutlet var textDescription: UITextField!
    @IBOutlet var durationHours: UITextField!
    @IBOutlet var durationMinutes: UITextField!
    @IBOutlet var dueDate: UIDatePicker!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        textDescription.layer.cornerRadius = 10.0
        textDescription.layer.borderWidth = 1
        let gcol = UIColor.lightGrayColor().CGColor
        textDescription.layer.borderColor = gcol
        
        textTask.layer.cornerRadius = 10.0
        textTask.layer.borderWidth = 1
        textTask.layer.borderColor = gcol
        
        durationHours.layer.cornerRadius = 10.0
        durationHours.layer.borderWidth = 1
        durationHours.layer.borderColor = gcol
        
        durationMinutes.layer.cornerRadius = 10.0
        durationMinutes.layer.borderWidth = 1
        durationMinutes.layer.borderColor = gcol
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func AddTaskClick(sender: UIButton){
        
        if durationHours.text!.isEmpty{
           durationHours.text = "0"
        }
        
        if durationMinutes.text!.isEmpty{
            durationMinutes.text = "0"
        }
        
        taskManager.addTask(textTask.text!, description: textDescription.text!, durHours: durationHours.text!, durMins: durationMinutes.text!, due: dueDate.date)
        self.view.endEditing(true)
        textTask.text = ""
        textDescription.text = ""
        self.tabBarController?.selectedIndex = 0
        

    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        self.view.endEditing(true)
    }

    func textFieldShouldReturn(textField: UITextField) -> Bool{
        textField.resignFirstResponder();
        return true
    }
    
    

}

