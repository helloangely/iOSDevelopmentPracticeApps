//
//  FirstViewController.swift
//  TaskHeroHomework
//
//  Copyright © 2016 qApp. All rights reserved.
//

import UIKit


class TaskListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    var selectedIndex: Int = 100
    
    
    @IBOutlet var tableTask: UITableView!
    @IBOutlet var nameLabel:UILabel!
    //let destination = segue.destinationViewController as? TimerViewController
    
    
    func refreshFields(){
        let myDefaults = NSUserDefaults.standardUserDefaults()
         myDefaults.synchronize()
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        //navigationController?.pushViewController(destination, animated: true)
        // Do any additional setup after loading the view, typically from a nib.
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        refreshFields()
        tableTask.reloadData()
    }
    
    func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath){
        if(editingStyle == UITableViewCellEditingStyle.Delete){
            taskManager.tasks.removeAtIndex(indexPath.row)
            tableTask.reloadData()
        }
    }
    

    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return taskManager.tasks.count
    }

    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell{
        
        let cell: UITableViewCell = UITableViewCell(style: UITableViewCellStyle.Subtitle, reuseIdentifier: "Default")
        
        cell.textLabel!.text = taskManager.tasks[indexPath.row].category
        cell.detailTextLabel!.text = taskManager.tasks[indexPath.row].descrip
        
        if flag {
        let imag : UIImage = UIImage(named: "check.png")!
        cell.imageView!.image = imag
        }
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        selectedIndex = indexPath.row
        performSegueWithIdentifier("segue", sender: self)
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "segue" {
            if let viewController:TimerViewController = segue.destinationViewController as? TimerViewController{
                viewController.indexPos = selectedIndex
            }
        }
    }
}

