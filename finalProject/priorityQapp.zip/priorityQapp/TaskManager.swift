//
//  TaskManager.swift
//  TaskHeroHomework
//
//  Copyright © 2016 qApp. All rights reserved.
//

import UIKit

var taskManager: TaskManager = TaskManager()

class task: NSObject, NSCoding {
    var category = "No Category"
    var descrip = "No Description"
    var durHours = "No hours"
    var durMins = "No mins"
    var dueDate = NSDate()
    
    init(cat: String, desc: String, durhrs: String, durmins: String, dt: NSDate) {
        category = cat
        descrip = desc
        durHours = durhrs
        durMins = durmins
        dueDate = dt
    }
    
    required convenience init?(coder aDecoder: NSCoder) {
        guard let category = aDecoder.decodeObjectForKey("category") as? String,
        let descrip = aDecoder.decodeObjectForKey("description") as? String,
        let durH = aDecoder.decodeObjectForKey("durationHours") as? String,
        let durM = aDecoder.decodeObjectForKey("durationMins") as? String,
        let dueDate = aDecoder.decodeObjectForKey("dueDate") as? NSDate
            else { return nil }
        
        self.init(
            cat: category,
            desc: descrip,
            durhrs: durH,
            durmins: durM,
            dt: dueDate
        )
    }

    func encodeWithCoder(aCoder: NSCoder) {
        aCoder.encodeObject(self.category, forKey: "category")
        aCoder.encodeObject(self.descrip, forKey: "description")
        aCoder.encodeObject(self.durHours, forKey: "durationHours")
        aCoder.encodeObject(self.durMins, forKey: "durationMins")
        aCoder.encodeObject(self.dueDate, forKey: "dueDate")
    }
    
    
}

class TaskManager {
    
    var tasks: [task]
    
    init() {
        tasks = [task]()
    }
    
    func addTask(category: String, description: String, durHours: String, durMins: String, due: NSDate){

        if tasks.count == 0{
            tasks.append(task(cat: category, desc: description, durhrs: durHours, durmins: durMins, dt: due))
            }
        else {
            var wasInsertFlag = false
            for i in 0...tasks.count-1{
                if due.compare(tasks[i].dueDate) == .OrderedAscending {
                    tasks.insert(task(cat: category, desc: description, durhrs: durHours, durmins: durMins, dt: due), atIndex: i)
                    wasInsertFlag = true
                    break;
               }
            }
            if wasInsertFlag == false {
                tasks.append(task(cat: category, desc: description, durhrs: durHours, durmins: durMins, dt: due))
            }

        print(tasks)
        }
            }
        }
    
    
    

